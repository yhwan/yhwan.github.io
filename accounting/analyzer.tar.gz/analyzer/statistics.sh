#!/bin/bash

# make directory
if [ ! -d "result" ]; then
	mkdir "result" 
fi

# retransmission volume vs. total volume
cat $1 | awk 'BEGIN                                                                 \
{ ret1k_up=0; ret1k_down=0; ret1k=0; tot1k_up=0; tot1k_down=0; tot1k=0;             \
  ret4k_up=0; ret4k_down=0; ret4k=0; tot4k_up=0; tot4k_down=0; tot4k=0;             \
  ret16k_up=0; ret16k_down=0; ret16k=0; tot16k_up=0; tot16k_down=0; tot16k=0;       \
  ret32k_up=0; ret32k_down=0; ret32k=0; tot32k_up=0; tot32k_down=0; tot32k=0;       \
  ret128k_up=0; ret128k_down=0; ret128k=0; tot128k_up=0; tot128k_down=0; tot128k=0; \
  ret512k_up=0; ret512k_down=0; ret512k=0; tot512k_up=0; tot512k_down=0; tot512k=0; \
  ret10m_up=0; ret10m_down=0; ret10m=0; tot10m_up=0; tot10m_down=0; tot10m=0;       \
  retrest_up=0; retrest_down=0; retrest=0; totrest_up=0; totrest_down=0; totrest=0; \
  ret_up=0; ret_down=0; ret=0; total_up=0; total_down=0; total=0 }                  \
{ ret_up += $10; ret_down += $12; ret += ($10+$12);                                 \
  total_up+=$3; total_down+= $4; total += ($3+$4);                                  \
if ($3 < 1024) { ret1k_up += $10; tot1k_up += $3; }                                 \
else if ($3 < 4 * 1024) { ret4k_up += $10; tot4k_up += $3; }                        \
else if ($3 < 16 * 1024) { ret16k_up += $10; tot16k_up += $3; }                     \
else if ($3 < 32 * 1024) { ret32k_up += $10; tot32k_up += $3; }                     \
else if ($3 < 128 * 1024) { ret128k_up += $10; tot128k_up += $3; }                  \
else if ($3 < 512 * 1024) { ret512k_up += $10; tot512k_up += $3; }                  \
else if ($3 < 10 * 1024 * 1024) { ret10m_up += $10; tot10m_up += $3; }              \
else { retrest_up += $10; totrest_up += $3; }                                       \
if ($4 < 1024) { ret1k_down += $12; tot1k_down += $4; }                             \
else if ($4 < 4 * 1024) { ret4k_down += $12; tot4k_down += $4; }                    \
else if ($4 < 16 * 1024) { ret16k_down += $12; tot16k_down += $4; }                 \
else if ($4 < 32 * 1024) { ret32k_down += $12; tot32k_down += $4; }                 \
else if ($4 < 128 * 1024) { ret128k_down += $12; tot128k_down += $4; }              \
else if ($4 < 512 * 1024) { ret512k_down += $12; tot512k_down += $4; }              \
else if ($4 < 10 * 1024 * 1024) { ret10m_down += $12; tot10m_down += $4; }          \
else { retrest_down += $12; totrest_down += $4; }                                   \
if ($3 + $4 < 1024) { ret1k += ($10+$12); tot1k += ($3+$4); }                       \
else if ($3 + $4 < 4 * 1024) { ret4k += ($10+$12); tot4k += ($3+$4); }              \
else if ($3 + $4 < 16 * 1024) { ret16k += ($10+$12); tot16k += ($3+$4); }           \
else if ($3 + $4 < 32 * 1024) { ret32k += ($10+$12); tot32k += ($3+$4); }           \
else if ($3 + $4 < 128 * 1024) { ret128k += ($10+$12); tot128k += ($3+$4); }        \
else if ($3 + $4 < 512 * 1024) { ret512k += ($10+$12); tot512k += ($3+$4); }        \
else if ($3 + $4 < 10 * 1024 * 1024) { ret10m += ($10+$12); tot10m += ($3+$4); }    \
else { retrest += ($10+$12); totrest += ($3+$4); }; }                               \
END { print "Size\tRetUp\tVolUp\tRetDown\tVolDown\tRetTot\tVolTot\n"                \
"<1K:\t"ret1k_up"\t"tot1k_up"\t"ret1k_down"\t"tot1k_down"\t"ret1k"\t"tot1k"\n"      \
"<4K:\t"ret4k_up"\t"tot4k_up"\t"ret4k_down"\t"tot4k_down"\t"ret4k"\t"tot4k"\n"      \
"<16K:\t"ret16k_up"\t"tot16k_up"\t"ret16k_down"\t"tot16k_down"\t"ret16k"\t"tot16k"\n" \
"<32K:\t"ret32k_up"\t"tot32k_up"\t"ret32k_down"\t"tot32k_down"\t"ret32k"\t"tot32k"\n" \
"<128K:\t"ret128k_up"\t"tot128k_up"\t"ret128k_down"\t"tot128k_down"\t"ret128k"\t"tot128k"\n" \
"<512K:\t"ret512k_up"\t"tot512k_up"\t"ret512k_down"\t"tot512k_down"\t"ret512k"\t"tot512k"\n" \
"<10M:\t"ret10m_up"\t"tot10m_up"\t"ret10m_down"\t"tot10m_down"\t"ret10m"\t"tot10m"\n"        \
">=10M:\t"retrest_up"\t"totrest_up"\t"retrest_down"\t"totrest_down"\t"retrest"\t"totrest"\n" \
"Total:\t"ret_up"\t"total_up"\t"ret_down"\t"total_down"\t"ret"\t"total}' | column -t  > result/$1_volumeStatistics.txt
cat $1 | awk '{ if ($3 < 1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*1024*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volume10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $10/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 $4 < 4*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volume10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $12/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeRest_down.txt
cat $1 | awk '{ print $10 / $3 }' | sort -g | uniq -c | column -t > result/$1_volumeTotal_up.txt
cat $1 | awk '{ print $12 / $4 }' | sort -g | uniq -c | column -t > result/$1_volumeTotal_down.txt
cat $1 | awk '{ val = ($10+$12) / ($3+$4); print val }' | sort -g | uniq -c | column -t > result/$1_volumeTotal.txt

# retransmission packet num vs. total packet num
cat $1 | awk 'BEGIN                                                                 \
{ ret1k_up=0; ret1k_down=0; ret1k=0; tot1k_up=0; tot1k_down=0; tot1k=0;             \
  ret4k_up=0; ret4k_down=0; ret4k=0; tot4k_up=0; tot4k_down=0; tot4k=0;             \
  ret16k_up=0; ret16k_down=0; ret16k=0; tot16k_up=0; tot16k_down=0; tot16k=0;       \
  ret32k_up=0; ret32k_down=0; ret32k=0; tot32k_up=0; tot32k_down=0; tot32k=0;       \
  ret128k_up=0; ret128k_down=0; ret128k=0; tot128k_up=0; tot128k_down=0; tot128k=0; \
  ret512k_up=0; ret512k_down=0; ret512k=0; tot512k_up=0; tot512k_down=0; tot512k=0; \
  ret10m_up=0; ret10m_down=0; ret10m=0; tot10m_up=0; tot10m_down=0; tot10m=0;       \
  retrest_up=0; retrest_down=0; retrest=0; totrest_up=0; totrest_down=0; totrest=0; \
  ret_up=0; ret_down=0; ret=0; total_up=0; total_down=0; total=0 }                  \
{ ret_up += $9; ret_down += $11; ret += ($9+$11);                                   \
  total_up+=$5; total_down+= $7; total += ($5+$7);                                  \
if ($3 < 1024) { ret1k_up += $9; tot1k_up += $5; }                                  \
else if ($3 < 4 * 1024) { ret4k_up += $9; tot4k_up += $5; }                         \
else if ($3 < 16 * 1024) { ret16k_up += $9; tot16k_up += $5; }                      \
else if ($3 < 32 * 1024) { ret32k_up += $9; tot32k_up += $5; }                      \
else if ($3 < 128 * 1024) { ret128k_up += $9; tot128k_up += $5; }                   \
else if ($3 < 512 * 1024) { ret512k_up += $9; tot512k_up += $5; }                   \
else if ($3 < 10 * 1024 * 1024) { ret10m_up += $9; tot10m_up += $5; }               \
else { retrest_up += $9; totrest_up += $5; }                                        \
if ($4 < 1024) { ret1k_down += $11; tot1k_down += $7; }                             \
else if ($4 < 4 * 1024) { ret4k_down += $11; tot4k_down += $7; }                    \
else if ($4 < 16 * 1024) { ret16k_down += $11; tot16k_down += $7; }                 \
else if ($4 < 32 * 1024) { ret32k_down += $11; tot32k_down += $7; }                 \
else if ($4 < 128 * 1024) { ret128k_down += $11; tot128k_down += $7; }              \
else if ($4 < 512 * 1024) { ret512k_down += $11; tot512k_down += $7; }              \
else if ($4 < 10 * 1024 * 1024) { ret10m_down += $11; tot10m_down += $7; }          \
else { retrest_down += $11; totrest_down += $7; }                                   \
if ($3 + $4 < 1024) { ret1k += ($9+$11); tot1k += ($5+$7); }                        \
else if ($3 + $4 < 4 * 1024) { ret4k += ($9+$11); tot4k += ($5+$7); }               \
else if ($3 + $4 < 16 * 1024) { ret16k += ($9+$11); tot16k += ($5+$7); }            \
else if ($3 + $4 < 32 * 1024) { ret32k += ($9+$11); tot32k += ($5+$7); }            \
else if ($3 + $4 < 128 * 1024) { ret128k += ($9+$11); tot128k += ($5+$7); }         \
else if ($3 + $4 < 512 * 1024) { ret512k += ($9+$11); tot512k += ($5+$7); }         \
else if ($3 + $4 < 10 * 1024 * 1024) { ret10m += ($9+$11); tot10m += ($5+$7); }     \
else { retrest += ($9+$11); totrest += ($5+$7); }; }                                \
END { print "Size\tRetUp\tPktUp\tRetDown\tPktDown\tRetTot\tPktTot\n"                \
"<1K:\t"ret1k_up"\t"tot1k_up"\t"ret1k_down"\t"tot1k_down"\t"ret1k"\t"tot1k"\n"      \
"<4K:\t"ret4k_up"\t"tot4k_up"\t"ret4k_down"\t"tot4k_down"\t"ret4k"\t"tot4k"\n"      \
"<16K:\t"ret16k_up"\t"tot16k_up"\t"ret16k_down"\t"tot16k_down"\t"ret16k"\t"tot16k"\n" \
"<32K:\t"ret32k_up"\t"tot32k_up"\t"ret32k_down"\t"tot32k_down"\t"ret32k"\t"tot32k"\n" \
"<128K:\t"ret128k_up"\t"tot128k_up"\t"ret128k_down"\t"tot128k_down"\t"ret128k"\t"tot128k"\n" \
"<512K:\t"ret512k_up"\t"tot512k_up"\t"ret512k_down"\t"tot512k_down"\t"ret512k"\t"tot512k"\n" \
"<10M:\t"ret10m_up"\t"tot10m_up"\t"ret10m_down"\t"tot10m_down"\t"ret10m"\t"tot10m"\n"        \
">=10M:\t"retrest_up"\t"totrest_up"\t"retrest_down"\t"totrest_down"\t"retrest"\t"totrest"\n" \
"Total:\t"ret_up"\t"total_up"\t"ret_down"\t"total_down"\t"ret"\t"total}' | column -t > result/$1_packetStatistics.txt
cat $1 | awk '{ if ($3 < 1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*1024*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packet10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 && $4 < 4*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packet10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetRest_down.txt
cat $1 | awk '{ print $9 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetTotal_up.txt
cat $1 | awk '{ print $11 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetTotal_down.txt
cat $1 | awk '{ val = ($9+$11) / ($5+$7); print val }' | sort -g | uniq -c | column -t > result/$1_packetTotal.txt

# duplicate ACK volume vs. total volume
cat $1 | awk 'BEGIN                                                                 \
{ ret1k_up=0; ret1k_down=0; ret1k=0; tot1k_up=0; tot1k_down=0; tot1k=0;             \
  ret4k_up=0; ret4k_down=0; ret4k=0; tot4k_up=0; tot4k_down=0; tot4k=0;             \
  ret16k_up=0; ret16k_down=0; ret16k=0; tot16k_up=0; tot16k_down=0; tot16k=0;       \
  ret32k_up=0; ret32k_down=0; ret32k=0; tot32k_up=0; tot32k_down=0; tot32k=0;       \
  ret128k_up=0; ret128k_down=0; ret128k=0; tot128k_up=0; tot128k_down=0; tot128k=0; \
  ret512k_up=0; ret512k_down=0; ret512k=0; tot512k_up=0; tot512k_down=0; tot512k=0; \
  ret10m_up=0; ret10m_down=0; ret10m=0; tot10m_up=0; tot10m_down=0; tot10m=0;       \
  retrest_up=0; retrest_down=0; retrest=0; totrest_up=0; totrest_down=0; totrest=0; \
  ret_up=0; ret_down=0; ret=0; total_up=0; total_down=0; total=0 }                  \
{ ret_up += $14; ret_down += $16; ret += ($14+$16);                                 \
  total_up+=$3; total_down+= $4; total += ($3+$4);                                  \
if ($3 < 1024) { ret1k_up += $14; tot1k_up += $3; }                                 \
else if ($3 < 4 * 1024) { ret4k_up += $14; tot4k_up += $3; }                        \
else if ($3 < 16 * 1024) { ret16k_up += $14; tot16k_up += $3; }                     \
else if ($3 < 32 * 1024) { ret32k_up += $14; tot32k_up += $3; }                     \
else if ($3 < 128 * 1024) { ret128k_up += $14; tot128k_up += $3; }                  \
else if ($3 < 512 * 1024) { ret512k_up += $14; tot512k_up += $3; }                  \
else if ($3 < 10 * 1024 * 1024) { ret10m_up += $14; tot10m_up += $3; }              \
else { retrest_up += $14; totrest_up += $3; }                                       \
if ($4 < 1024) { ret1k_down += $16; tot1k_down += $4; }                             \
else if ($4 < 4 * 1024) { ret4k_down += $16; tot4k_down += $4; }                    \
else if ($4 < 16 * 1024) { ret16k_down += $16; tot16k_down += $4; }                 \
else if ($4 < 32 * 1024) { ret32k_down += $16; tot32k_down += $4; }                 \
else if ($4 < 128 * 1024) { ret128k_down += $16; tot128k_down += $4; }              \
else if ($4 < 512 * 1024) { ret512k_down += $16; tot512k_down += $4; }              \
else if ($4 < 10 * 1024 * 1024) { ret10m_down += $16; tot10m_down += $4; }          \
else { retrest_down += $16; totrest_down += $4; }                                   \
if ($3 + $4 < 1024) { ret1k += ($14+$16); tot1k += ($3+$4); }                       \
else if ($3 + $4 < 4 * 1024) { ret4k += ($14+$16); tot4k += ($3+$4); }              \
else if ($3 + $4 < 16 * 1024) { ret16k += ($14+$16); tot16k += ($3+$4); }           \
else if ($3 + $4 < 32 * 1024) { ret32k += ($14+$16); tot32k += ($3+$4); }           \
else if ($3 + $4 < 128 * 1024) { ret128k += ($14+$16); tot128k += ($3+$4); }        \
else if ($3 + $4 < 512 * 1024) { ret512k += ($14+$16); tot512k += ($3+$4); }        \
else if ($3 + $4 < 10 * 1024 * 1024) { ret10m += ($14+$16); tot10m += ($3+$4); }    \
else { retrest += ($14+$16); totrest += ($3+$4); }; }                               \
END { print "Size\tDupUp\tVolUp\tDupDown\tVolDown\tDupTot\tVolTot\n"                \
"<1K:\t"ret1k_up"\t"tot1k_up"\t"ret1k_down"\t"tot1k_down"\t"ret1k"\t"tot1k"\n"      \
"<4K:\t"ret4k_up"\t"tot4k_up"\t"ret4k_down"\t"tot4k_down"\t"ret4k"\t"tot4k"\n"      \
"<16K:\t"ret16k_up"\t"tot16k_up"\t"ret16k_down"\t"tot16k_down"\t"ret16k"\t"tot16k"\n" \
"<32K:\t"ret32k_up"\t"tot32k_up"\t"ret32k_down"\t"tot32k_down"\t"ret32k"\t"tot32k"\n" \
"<128K:\t"ret128k_up"\t"tot128k_up"\t"ret128k_down"\t"tot128k_down"\t"ret128k"\t"tot128k"\n" \
"<512K:\t"ret512k_up"\t"tot512k_up"\t"ret512k_down"\t"tot512k_down"\t"ret512k"\t"tot512k"\n" \
"<10M:\t"ret10m_up"\t"tot10m_up"\t"ret10m_down"\t"tot10m_down"\t"ret10m"\t"tot10m"\n"        \
">=10M:\t"retrest_up"\t"totrest_up"\t"retrest_down"\t"totrest_down"\t"retrest"\t"totrest"\n" \
"Total:\t"ret_up"\t"total_up"\t"ret_down"\t"total_down"\t"ret"\t"total}' | column -t > result/$1_volumeAckStatistics.txt
cat $1 | awk '{ if ($3 < 1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*1024*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAck10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $14/$3 }' | sort -g | uniq -c | column -t > result/$1_volumeAckRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 $4 < 4*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAck10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $16/$4 }' | sort -g | uniq -c | column -t > result/$1_volumeAckRest_down.txt
cat $1 | awk '{ print $14 / $3 }' | sort -g | uniq -c | column -t > result/$1_volumeAckTotal_up.txt
cat $1 | awk '{ print $16 / $4 }' | sort -g | uniq -c | column -t > result/$1_volumeAckTotal_down.txt
cat $1 | awk '{ val = ($14+$16) / ($3+$4); print val }' | sort -g | uniq -c | column -t > result/$1_volumeAckTotal.txt

# duplicate ACK packet num vs. total packet num
cat $1 | awk 'BEGIN                                                                 \
{ ret1k_up=0; ret1k_down=0; ret1k=0; tot1k_up=0; tot1k_down=0; tot1k=0;             \
  ret4k_up=0; ret4k_down=0; ret4k=0; tot4k_up=0; tot4k_down=0; tot4k=0;             \
  ret16k_up=0; ret16k_down=0; ret16k=0; tot16k_up=0; tot16k_down=0; tot16k=0;       \
  ret32k_up=0; ret32k_down=0; ret32k=0; tot32k_up=0; tot32k_down=0; tot32k=0;       \
  ret128k_up=0; ret128k_down=0; ret128k=0; tot128k_up=0; tot128k_down=0; tot128k=0; \
  ret512k_up=0; ret512k_down=0; ret512k=0; tot512k_up=0; tot512k_down=0; tot512k=0; \
  ret10m_up=0; ret10m_down=0; ret10m=0; tot10m_up=0; tot10m_down=0; tot10m=0;       \
  retrest_up=0; retrest_down=0; retrest=0; totrest_up=0; totrest_down=0; totrest=0; \
  ret_up=0; ret_down=0; ret=0; total_up=0; total_down=0; total=0 }                  \
{ ret_up += $13; ret_down += $15; ret += ($13+$15);                                 \
  total_up+=$5; total_down+= $7; total += ($5+$7);                                  \
if ($3 < 1024) { ret1k_up += $13; tot1k_up += $5; }                                 \
else if ($3 < 4 * 1024) { ret4k_up += $13; tot4k_up += $5; }                        \
else if ($3 < 16 * 1024) { ret16k_up += $13; tot16k_up += $5; }                     \
else if ($3 < 32 * 1024) { ret32k_up += $13; tot32k_up += $5; }                     \
else if ($3 < 128 * 1024) { ret128k_up += $13; tot128k_up += $5; }                  \
else if ($3 < 512 * 1024) { ret512k_up += $13; tot512k_up += $5; }                  \
else if ($3 < 10 * 1024 * 1024) { ret10m_up += $13; tot10m_up += $5; }              \
else { retrest_up += $13; totrest_up += $5; }                                       \
if ($4 < 1024) { ret1k_down += $15; tot1k_down += $7; }                             \
else if ($4 < 4 * 1024) { ret4k_down += $15; tot4k_down += $7; }                    \
else if ($4 < 16 * 1024) { ret16k_down += $15; tot16k_down += $7; }                 \
else if ($4 < 32 * 1024) { ret32k_down += $15; tot32k_down += $7; }                 \
else if ($4 < 128 * 1024) { ret128k_down += $15; tot128k_down += $7; }              \
else if ($4 < 512 * 1024) { ret512k_down += $15; tot512k_down += $7; }              \
else if ($4 < 10 * 1024 * 1024) { ret10m_down += $15; tot10m_down += $7; }          \
else { retrest_down += $15; totrest_down += $7; }                                   \
if ($3 + $4 < 1024) { ret1k += ($13+$15); tot1k += ($5+$7); }                       \
else if ($3 + $4 < 4 * 1024) { ret4k += ($13+$15); tot4k += ($5+$7); }              \
else if ($3 + $4 < 16 * 1024) { ret16k += ($13+$15); tot16k += ($5+$7); }           \
else if ($3 + $4 < 32 * 1024) { ret32k += ($13+$15); tot32k += ($5+$7); }           \
else if ($3 + $4 < 128 * 1024) { ret128k += ($13+$15); tot128k += ($5+$7); }        \
else if ($3 + $4 < 512 * 1024) { ret512k += ($13+$15); tot512k += ($5+$7); }        \
else if ($3 + $4 < 10 * 1024 * 1024) { ret10m += ($13+$15); tot10m += ($5+$7); }    \
else { retrest += ($13+$15); totrest += ($5+$7); }; }                               \
END { print "Size\tDupUp\tPktUp\tDupDown\tPktDown\tDupTot\tPktTot\n"                \
"<1K:\t"ret1k_up"\t"tot1k_up"\t"ret1k_down"\t"tot1k_down"\t"ret1k"\t"tot1k"\n"      \
"<4K:\t"ret4k_up"\t"tot4k_up"\t"ret4k_down"\t"tot4k_down"\t"ret4k"\t"tot4k"\n"      \
"<16K:\t"ret16k_up"\t"tot16k_up"\t"ret16k_down"\t"tot16k_down"\t"ret16k"\t"tot16k"\n" \
"<32K:\t"ret32k_up"\t"tot32k_up"\t"ret32k_down"\t"tot32k_down"\t"ret32k"\t"tot32k"\n" \
"<128K:\t"ret128k_up"\t"tot128k_up"\t"ret128k_down"\t"tot128k_down"\t"ret128k"\t"tot128k"\n" \
"<512K:\t"ret512k_up"\t"tot512k_up"\t"ret512k_down"\t"tot512k_down"\t"ret512k"\t"tot512k"\n" \
"<10M:\t"ret10m_up"\t"tot10m_up"\t"ret10m_down"\t"tot10m_down"\t"ret10m"\t"tot10m"\n"        \
">=10M:\t"retrest_up"\t"totrest_up"\t"retrest_down"\t"totrest_down"\t"retrest"\t"totrest"\n" \
"Total:\t"ret_up"\t"total_up"\t"ret_down"\t"total_down"\t"ret"\t"total}' | column -t > result/$1_packetAckStatistics.txt
cat $1 | awk '{ if ($3 < 1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*1024*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAck10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAckRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 && $4 < 4*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAck10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAckRest_down.txt
cat $1 | awk '{ print $13 / $5 }' | sort -g | uniq -c | column -t > result/$1_packetAckTotal_up.txt
cat $1 | awk '{ print $15 / $7 }' | sort -g | uniq -c | column -t > result/$1_packetAckTotal_down.txt
cat $1 | awk '{ val = ($13+$15) / ($5+$7); print val }' | sort -g | uniq -c | column -t > result/$1_packetAckTotal.txt

# retransmission data packet burst number
cat $1 | awk '{ if ($3 < 1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*10241024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burst10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $17 }' | sort -g | uniq -c | column -t > result/$1_burstRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 && $4 < 4*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burst10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $18 }' | sort -g | uniq -c | column -t > result/$1_burstRest_down.txt
cat $1 | awk '{ print $17 }' | sort -g | uniq -c | column -t > result/$1_burstTotal_up.txt
cat $1 | awk '{ print $18 }' | sort -g | uniq -c | column -t > result/$1_burstTotal_down.txt

# duplicate ack burst number
cat $1 | awk '{ if ($3 < 1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck1k_up.txt
cat $1 | awk '{ if ($3 >= 1024 && $3 < 4*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck4k_up.txt
cat $1 | awk '{ if ($3 >= 4*1024 && $3 < 16*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck16k_up.txt
cat $1 | awk '{ if ($3 >= 16*1024 && $3 < 32*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck32k_up.txt
cat $1 | awk '{ if ($3 >= 32*1024 && $3 < 128*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck128k_up.txt
cat $1 | awk '{ if ($3 >= 128*1024 && $3 < 512*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck512k_up.txt
cat $1 | awk '{ if ($3 >= 512*1024 && $3 < 10*10241024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAck10m_up.txt
cat $1 | awk '{ if ($3 >= 10*1024*1024) print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAckRest_up.txt
cat $1 | awk '{ if ($4 < 1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck1k_down.txt
cat $1 | awk '{ if ($4 >= 1024 && $4 < 4*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck4k_down.txt
cat $1 | awk '{ if ($4 >= 4*1024 && $4 < 16*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck16k_down.txt
cat $1 | awk '{ if ($4 >= 16*1024 && $4 < 32*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck32k_down.txt
cat $1 | awk '{ if ($4 >= 32*1024 && $4 < 128*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck128k_down.txt
cat $1 | awk '{ if ($4 >= 128*1024 && $4 < 512*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck512k_down.txt
cat $1 | awk '{ if ($4 >= 512*1024 && $4 < 10*1024*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAck10m_down.txt
cat $1 | awk '{ if ($4 >= 10*1024*1024) print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAckRest_down.txt
cat $1 | awk '{ print $19 }' | sort -g | uniq -c | column -t > result/$1_burstAckTotal_up.txt
cat $1 | awk '{ print $20 }' | sort -g | uniq -c | column -t > result/$1_burstAckTotal_down.txt

# number of flows ended with RST vs. total flows
cat $1 | awk 'BEGIN                                                                     \
{ rst1k_src=0; rst1k_dst=0; tot1k=0; rst4k_src=0; rst4k_dst=0; tot4k=0;                 \
  rst16k_src=0; rst16k_dst=0; tot16k=0; rst32k_src=0; rst32k_dst=0; tot32k=0;           \
  rst128k_src=0; rst128k_dst=0; tot128k=0; rst512k_src=0; rst512k_dst=0; tot512k=0;     \
  rst10m_src=0; rst10m_dst=0; tot10m=0; rstrest_src=0; rstrest_dst=0; totrest=0;        \
  rst_src=0; rst_dst=0; tot=0; }                                                        \
{ rst_src += $21; rst_dst += $22; tot++;                                                \
if ($3 + $4 < 1024) { rst1k_src += $21; rst1k_dst += $22; tot1k++; }                    \
else if ($3 + $4 < 4 * 1024) { rst4k_src += $21; rst4k_dst += $22; tot4k++; }           \
else if ($3 + $4 < 16 * 1024) { rst16k_src += $21; rst16k_dst += $22; tot16k++; }       \
else if ($3 + $4 < 32 * 1024) { rst32k_src += $21; rst32k_dst += $22; tot32k++; }       \
else if ($3 + $4 < 128 * 1024) { rst128k_src += $21; rst128k_dst += $22; tot128k++; }   \
else if ($3 + $4 < 512 * 1024) { rst512k_src += $21; rst512k_dst += $22; tot512k++; }   \
else if ($3 + $4 < 10 * 1024 * 1024) { rst10m_src += $21; rst10m_dst += $22; tot10m++; }\
else { rstrest_src += $21; rstrest_dst += $22; totrest++; }; }                          \
END { print "Size\tRSTup\tRSTdw\tTotal\n"                                               \
            "<1K:\t"rst1k_src"\t"rst1k_dst"\t"tot1k"\n"                                 \
            "<4K:\t"rst4k_src"\t"rst4k_dst"\t"tot4k"\n"                                 \
            "<16K:\t"rst16k_src"\t"rst16k_dst"\t"tot16k"\n"                             \
            "<32K:\t"rst32k_src"\t"rst32k_dst"\t"tot32k"\n"                             \
            "<128K:\t"rst128k_src"\t"rst128k_dst"\t"tot128k"\n"                         \
            "<512K:\t"rst512k_src"\t"rst512k_dst"\t"tot512k"\n"                         \
            "<10M:\t"rst10m_src"\t"rst10m_dst"\t"tot10m"\n"                             \
            ">=10M:\t"rstrest_src"\t"rstrest_dst"\t"totrest"\n"                         \
            "Total:\t"rst_src"\t"rst_dst"\t"tot"\n"                                     \
}' | column -t > result/$1_rstStatistics.txt