#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pcap.h>
#include <signal.h>
#include <linux/tcp.h>
#include <net/if.h>
#include <net/ethernet.h>
#include <sys/ioctl.h>
#include <string.h>
#include <arpa/inet.h>
#include "flow.h"

/* define variable */
#define BUFSIZE 1024
#define WIRED 14               
#define CELLULAR 16
#define SNAPLEN 96
#define TRUE 1
#define FALSE 0

/* global variable */
uint32_t src_ip;
pcap_t *handle;                 // session handle 
static int count = 0;           // number of captured packet

/*--------------------------------------------------------------------*/
static inline int
InitLogFile(char *filename)
{
	/* open log file */
	return open(filename, O_CREAT|O_TRUNC|O_RDWR, S_IRUSR|S_IWUSR);
}
/*--------------------------------------------------------------------*/
static void 
sigHandler(int signum)
{
	/* break the packet capture loop */
	pcap_breakloop(handle);
}
/*--------------------------------------------------------------------*/
static int
CalculateOverlap(uint32_t seq, uint32_t len, buffer *buf, int *overlap_len) 
{
	int res = 0;
	uint32_t start, end;

	/* packet buffer is overlapped */
	if (seq > buf->seq + buf->payloadlen || buf->seq > seq + len) {
		return FALSE;
	}
	else {
		/* calculate length of overlapped region */
		start = (seq > buf->seq) ? seq : buf->seq;
		end = (seq + len < buf->seq + buf->payloadlen) ? 
			seq + len : buf->seq + buf->payloadlen;
		*overlap_len = end - start;
		
		/* set new payload length and seq */
		buf->payloadlen = MAX(buf->seq + buf->payloadlen, seq + len) 
			- MIN(buf->seq, seq);
		buf->seq = MIN(buf->seq, seq);

		return TRUE;
	}
}
/*--------------------------------------------------------------------*/
static void
HandleRST(flow *cur_flow)
{
	uint32_t max;

	/* no end sequence number due to rst from destination */
	if ((max = MAX(cur_flow->lastByteSent[UP], cur_flow->nextByteExpected[UP])) != 0) {
		cur_flow->EndSeq[UP] = max;
	}
	/* no end sequence number due to rst from source */
	if ((max = MAX(cur_flow->lastByteSent[DOWN], cur_flow->nextByteExpected[DOWN])) != 0) {
		cur_flow->EndSeq[DOWN] = max;
	}
}
/*--------------------------------------------------------------------*/
static void
HandleTCPPayload(flow *cur_flow, unsigned int dir, 
				 unsigned short headerlen, uint32_t seq, uint32_t payloadlen)
{
	buffer *buf, *temp_buf, *prev_buf, *pprev_buf;
	int overlap_len = 0, merged = FALSE;

	/* if seq + payloadlen is less than lastByteSent, set as retransmission */
	/* if fast retransmission packet, set as retransmission */
	if (seq + payloadlen <= cur_flow->lastByteSent[dir] ||
		(cur_flow->fastRetransmit[dir] == TRUE && cur_flow->nextByteExpected[dir] == seq)) {
		cur_flow->retransmitVol[dir] += headerlen + payloadlen;
		cur_flow->retransmitNum[dir]++;
		cur_flow->burstNum[dir]++;
		return;
	}

	/* set new buffer */
	buf = GetBuffer();
	buf->seq = seq;
	buf->headerlen = headerlen;
	buf->payloadlen = payloadlen;
	buf->next_buf = NULL;

	/* search through the buffer list */
	for (temp_buf = cur_flow->bufRing[dir].head_buf, prev_buf = NULL, pprev_buf = NULL; 
		 temp_buf != NULL;
		 pprev_buf = prev_buf, prev_buf = temp_buf, temp_buf = temp_buf->next_buf) {
		
		if (CalculateOverlap(buf->seq, buf->payloadlen, temp_buf, &overlap_len)) {
			if (overlap_len > 0) {
				/* add retransmitted length = headerlen + overlapped length */
				cur_flow->retransmitVol[dir] += buf->headerlen + overlap_len;
				cur_flow->retransmitNum[dir]++;
				cur_flow->burstNum[dir]++;
			}
			
			/* remove buffer from buffer list if it's previous buffer */
            if (prev_buf == buf) {
                if (pprev_buf) {
					/* connect previous previous buffer to current buffer */
                    pprev_buf->next_buf = temp_buf;
				}
                else {
					/* set current buffer to head buffer */
                    cur_flow->bufRing[dir].head_buf = temp_buf;
				}
				prev_buf = pprev_buf;
            }
            AddToFreeBufferList(buf);
            buf = temp_buf;
			merged = TRUE;
		}
		else if (merged || seq + payloadlen < temp_buf->seq) {
			break;
		}
	}
	/* no overlap */
	if (!merged) {
		/* add first buffer to the buffer ring */
		if (cur_flow->bufRing[dir].head_buf == NULL) {
			cur_flow->bufRing[dir].head_buf = buf;
		}
		/* buffer has smaller seq than first buffer's seq in buffer list */
		else if (seq < cur_flow->bufRing[dir].head_buf->seq +
				 cur_flow->bufRing[dir].head_buf->payloadlen) {
			buf->next_buf = cur_flow->bufRing[dir].head_buf;
			cur_flow->bufRing[dir].head_buf = buf;
		}
		/* buffer has smaller seq than next buffer's seq in buffer list */
		else {
			prev_buf->next_buf = buf;
			buf->next_buf = temp_buf;
		}
	}

	/* number of retransmision packet in a row */
	if (overlap_len == 0) {
		if (cur_flow->burstNum[dir] > cur_flow->burstMax[dir]) {
			cur_flow->burstMax[dir] = cur_flow->burstNum[dir];
		}
		cur_flow->burstNum[dir] = 0;
	}

	if (cur_flow->bufRing[dir].head_buf) {
		/* if next expected data packet is found */
		if (cur_flow->bufRing[dir].head_buf->seq == cur_flow->lastByteSent[dir]) {
			cur_flow->lastByteSent[dir] += cur_flow->bufRing[dir].head_buf->payloadlen;
			buf = cur_flow->bufRing[dir].head_buf;
			cur_flow->bufRing[dir].head_buf = cur_flow->bufRing[dir].head_buf->next_buf;
			AddToFreeBufferList(buf);
		}
	}
}
/*--------------------------------------------------------------------*/
static void 
process_packet(u_char *arg, 
			   const struct pcap_pkthdr* header, 
			   const u_char *packet)
{
#define OPPOSITE(dir) ((dir == UP) ? DOWN : UP)
	flow *cur_flow = NULL, temp_flow1, temp_flow2;
	char log[BUFSIZE];
	int len;
	unsigned int dir, dir_r;
	uint32_t seq_num, ack_seq, tot_len; 
	struct ethhdr *eth = (struct ethhdr *)(packet);
	int eth_len;

	/* check whether packet is from wired/cell */
	if ((ntohs(eth->h_proto) == ETH_P_IP))
		eth_len = WIRED;
	else
		eth_len = CELLULAR;

	struct iphdr *iph = (struct iphdr *)(packet + eth_len);
	struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr) + eth_len);
	uint8_t *payload = (uint8_t *)tcph + (tcph->doff << 2);
	int payloadlen = ntohs(iph->tot_len) - (payload - (u_char *)iph);
	int headerlen = ntohs(iph->tot_len) - payloadlen;

	/* only process tcp packets */
	if (iph->protocol != IPPROTO_TCP)
		return;

	/* increment captured packet count */
	count++;

	/* set appropriate values */
	tot_len = ntohs(iph->tot_len);
	seq_num = ntohl(tcph->seq);
	ack_seq = ntohl(tcph->ack_seq);

	/* set address to search for flow */
	temp_flow1.saddr = iph->saddr;
	temp_flow1.daddr = iph->daddr;
	temp_flow1.sport = tcph->source;
	temp_flow1.dport = tcph->dest;
	temp_flow2.saddr = iph->daddr;
	temp_flow2.daddr = iph->saddr;
	temp_flow2.sport = tcph->dest;
	temp_flow2.dport = tcph->source;

	/* check for existing flow */
	if ((cur_flow = SearchFlow(&temp_flow1)) == NULL &&
		(cur_flow = SearchFlow(&temp_flow2)) == NULL){
		if (!tcph->syn || tcph->ack)
			return;

		/* create new flow */
		cur_flow = (flow *)calloc(1, sizeof(struct flow));
		if (cur_flow == NULL) {
			fprintf(stderr, "malloc() error\n");
			exit(-1);
		}

		/* set parameters */
		cur_flow->saddr = iph->saddr;
		cur_flow->daddr = iph->daddr;
		cur_flow->sport = tcph->source;
		cur_flow->dport = tcph->dest;
		cur_flow->StartSeq[UP] = seq_num;
		cur_flow->EndSeq[UP] = seq_num;

		/* statistics */
		cur_flow->volume[UP] = tot_len;
		cur_flow->packetNum[UP] = 1;

		/* retransmission-related */
		cur_flow->lastByteSent[UP] = seq_num + 1;

		/* insert new flow to hash table */
		InsertFlow(cur_flow);
		return;
	}

	/* check direction */
	dir = (cur_flow->saddr == iph->saddr) ? UP : DOWN;
	dir_r = OPPOSITE(dir);

	/* increase volume & packet num */
	cur_flow->volume[dir] += tot_len;
	cur_flow->packetNum[dir]++;

	/* retransmitted syn */
	if (tcph->syn && !tcph->ack) {
		cur_flow->dupAckVol[dir] += tot_len;
		cur_flow->dupAckNum[dir]++;
		cur_flow->burstAckNum[dir]++;
	}

	/* received syn+ack */
	if (tcph->syn && tcph->ack) {
		/* retransmitted syn+ack */
		if (cur_flow->StartSeq[DOWN] == seq_num) {
			cur_flow->dupAckVol[dir] += tot_len;
			cur_flow->dupAckNum[dir]++;
			cur_flow->burstAckNum[dir]++;
		}
		else {
			/* set parameter */
			cur_flow->StartSeq[DOWN] = seq_num;
			cur_flow->EndSeq[DOWN] = seq_num;
			
			/* retransmission-related */
			cur_flow->lastByteSent[DOWN] = seq_num + 1;
		}
		return;
	}

	/* data */
	if (payloadlen > 0) {
		/* handle seq & payload */
		HandleTCPPayload(cur_flow, dir, headerlen, seq_num, payloadlen);
		
		/* set ack */
		if (ack_seq > cur_flow->nextByteExpected[dir_r]) {
			cur_flow->nextByteExpected[dir_r] = ack_seq;
		}
	}
	/* ack */
	else if (tcph->ack && !tcph->fin && !tcph->rst) {
		/* close flow if there is a lost segment */
		if (cur_flow->lastByteSent[dir_r] < ack_seq) {
			cur_flow->segment_lost = TRUE;
		}

		/* check for duplicate ack */
		if (cur_flow->nextByteExpected[dir_r] >= ack_seq) {
			cur_flow->dupAckVol[dir] += tot_len;
			cur_flow->dupAckNum[dir]++;
			cur_flow->burstAckNum[dir]++;
			
			/* fast retransmission if 3 duplicate ACKs arrived */
			if (cur_flow->burstAckNum[dir] >= 3) {
				cur_flow->fastRetransmit[dir_r] = TRUE;
			}
		}
		else {
			cur_flow->nextByteExpected[dir_r] = ack_seq;
			if (cur_flow->burstAckNum[dir] > cur_flow->burstAckMax[dir]) {
				cur_flow->burstAckMax[dir] = cur_flow->burstAckNum[dir];
			}
			cur_flow->burstAckNum[dir] = 0;
			cur_flow->fastRetransmit[dir_r] = FALSE;
		}
	}

	/* received fin */
	if (tcph->fin) {
		cur_flow->EndSeq[dir] = seq_num;
		cur_flow->lastByteSent[dir]++;
		if (dir == UP)
			cur_flow->received_fin_src = TRUE;
		else
			cur_flow->received_fin_dst = TRUE;
	}
	/* received rst */
	else if (tcph->rst) {
		cur_flow->EndSeq[dir] = seq_num;
		if (dir == UP) {
			cur_flow->received_rst_src = TRUE;
		}
		else {
			cur_flow->received_rst_dst = TRUE;
		}

		/* rst is actually normal fin+ack */
		if (tcph->ack) {
			cur_flow->ignore_rst = TRUE;
			cur_flow->EndSeq[dir] = seq_num;
			cur_flow->EndSeq[dir_r] = ack_seq;
		}	
		/* handle real rst */
		else {
			HandleRST(cur_flow);
			/* if fin was received before, normal fin+ack */
			if (cur_flow->received_fin_src || cur_flow->received_fin_dst) {
				cur_flow->ignore_rst = TRUE;
				cur_flow->EndSeq[dir] = seq_num;
			}
		}
	}

	/* remove flow if there was a lost segment */
	// DILEMMA: flows with large retransmissions have some lost segments
	/* 
	if (cur_flow->segment_lost) {
		RemoveFlow(cur_flow);
		free(cur_flow);
		return;
	}
	*/

	/* check if flow must be closed */
	if ((cur_flow->received_fin_src && cur_flow->received_fin_dst)
		|| cur_flow->received_rst_src || cur_flow->received_rst_dst) {
		/* burst retransmission num */
		if (cur_flow->burstNum[UP] > cur_flow->burstMax[UP]) {
			cur_flow->burstMax[UP] = cur_flow->burstNum[UP];
		}
		if (cur_flow->burstNum[DOWN] > cur_flow->burstMax[DOWN]) {
			cur_flow->burstMax[DOWN] = cur_flow->burstNum[DOWN];
		}
		if (cur_flow->burstAckNum[UP] > cur_flow->burstAckMax[UP]) {
			cur_flow->burstAckMax[UP] = cur_flow->burstAckNum[UP];
		}
		if (cur_flow->burstAckNum[DOWN] > cur_flow->burstAckMax[DOWN]) {
			cur_flow->burstAckMax[DOWN] = cur_flow->burstAckNum[DOWN];
		}

		/* handle rst */
		if (cur_flow->ignore_rst) {
			cur_flow->received_rst_src = FALSE;
			cur_flow->received_rst_dst = FALSE;
		}

		/* source & destination ip */
		char srcIP[16], dstIP[16];
		strncpy(srcIP, inet_ntoa(*(struct in_addr *)&cur_flow->saddr), 16);
		strncpy(dstIP, inet_ntoa(*(struct in_addr *)&cur_flow->daddr), 16);
		
		/* create log */
		/* source IP : source port
		   destination IP : destination port
		   total volume (up/downlink)
		   total packet number, content size (uplink)
		   total packet number, content size (downlink)
		   retransmit packet number, volume (uplink)
		   retransmit packet number, volume (downlink)
		   duplicate ACK number, volume (uplink)
		   duplicate ACK number, volume (downlink)
		   retransmission data packet burst number (up/downlink)
		   duplicate ack burst number (up/downlink)
		   whether ended by RST (up/downlink)
		*/
		fprintf(stdout, "%s:%u\t%s:%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\t"
				"%u\t%u\n", 
				srcIP, ntohs(cur_flow->sport),
				dstIP, ntohs(cur_flow->dport),
				cur_flow->volume[UP], cur_flow->volume[DOWN],
				cur_flow->packetNum[UP], cur_flow->EndSeq[UP] - cur_flow->StartSeq[UP],
				cur_flow->packetNum[DOWN], cur_flow->EndSeq[DOWN] - cur_flow->StartSeq[DOWN],
				cur_flow->retransmitNum[UP], cur_flow->retransmitVol[UP],
				cur_flow->retransmitNum[DOWN], cur_flow->retransmitVol[DOWN],
				cur_flow->dupAckNum[UP], cur_flow->dupAckVol[UP],
				cur_flow->dupAckNum[DOWN], cur_flow->dupAckVol[DOWN],
				cur_flow->burstMax[UP], cur_flow->burstMax[DOWN],
				cur_flow->burstAckMax[UP], cur_flow->burstAckMax[DOWN],
				cur_flow->received_rst_src, cur_flow->received_rst_dst);
		
		/* remove flow */
		RemoveFlow(cur_flow);
		free(cur_flow);
	}
}
/*--------------------------------------------------------------------*/
int 
main(int argc, char *argv[])
{
	char errbuf[PCAP_ERRBUF_SIZE];  // error string 
	int fd, i;

	/* check input parameters */
	if (argc < 2) {
		fprintf(stderr, "Usage: %s <pcap files...>\n", argv[0]);
		return -1;
	}

	/* initialize flow hash table */
	InitHashTable();

	/* initialize buffer list */
	InitializeBufferList();

	/* set SIGINT signal handler */
	if (signal(SIGINT, sigHandler) == SIG_ERR) {
		fprintf(stderr, "Couldn't set SIGINT signal handler\n");
		return -1;
	}

	/* read multiple pcap files */
	for (i = 1; i < argc; i++) {
		fprintf(stderr, "reading %s\n", argv[i]);

		/* open pcap file to read */
		handle = pcap_open_offline(argv[i], errbuf);
		if (handle == NULL) {
			fprintf(stderr, "Couldn't open pcap file %s: %s\n", argv[i], errbuf);
			return -1;
		}
		
		/* begin reading pcap file */
		pcap_loop(handle, 0, process_packet, NULL);
		
		/* close the session */
		pcap_close(handle);
	}

	fprintf(stderr, "%d packets read\n", count);

	return 0;
}
/*--------------------------------------------------------------------*/
