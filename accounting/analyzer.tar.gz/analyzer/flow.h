#ifndef __FLOW_H_
#define __FLOW_H_

#include <netinet/ip.h>
#include "queue.h"

#define UP 0
#define DOWN 1

#define MIN(a, b) (((a)<(b))?(a):(b))
#define MAX(a, b) (((a)>(b))?(a):(b))

/* buffer struct */
typedef struct buffer
{
	uint32_t seq;
	uint32_t headerlen;
	uint32_t payloadlen;
	struct buffer *next_buf;
	TAILQ_ENTRY(buffer) link;
} buffer;

/* buffer ring */
struct buffer_ring
{
	struct buffer *head_buf;
};

/* flow struct */
typedef struct flow 
{
	/* IP address */
	uint32_t saddr;
	uint32_t daddr;

	/* port */
	uint16_t sport;
	uint16_t dport;

	/* buffer ring */
	struct buffer_ring bufRing[2];

	/* statistics */
	uint32_t volume[2];
	uint32_t packetNum[2];
	uint32_t retransmitNum[2];
	uint32_t retransmitVol[2];
	uint32_t dupAckNum[2];
	uint32_t dupAckVol[2];
	uint32_t burstNum[2];
	uint32_t burstMax[2];
	uint32_t burstAckNum[2];
	uint32_t burstAckMax[2];

	/* sequence number */
	uint32_t StartSeq[2];
	uint32_t EndSeq[2];

	/* retransmission-related variables */
	uint32_t lastByteSent[2];
	uint32_t nextByteExpected[2];
	int fastRetransmit[2];

	/* flag */
	uint8_t received_fin_src:1,
   		    received_fin_dst:1,
		    received_rst_src:1,
		    received_rst_dst:1,
		    ignore_rst:1,
		    segment_lost:1;

	/* list chunk list */
	LIST_ENTRY(flow) link;
} flow;

/* hash table */
unsigned int GetHash(char *s, int len);
void InitHashTable(void);
flow * SearchFlow(flow *f);
void InsertFlow(flow *f);
void RemoveFlow(flow *f);

/* buffer list */
void InitializeBufferList(void);
buffer *GetBuffer(void);
void AddToFreeBufferList(buffer *b);

#endif
