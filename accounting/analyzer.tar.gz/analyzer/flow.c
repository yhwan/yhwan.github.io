#include <stdio.h>
#include <stdlib.h>
#include "flow.h"

#define NUM_CH_BINS 65536
#define NUM_CH (NUM_CH_BINS * 192L)

static int g_availChunks = NUM_CH;
LIST_HEAD(, flow) g_flowBins[NUM_CH_BINS]; /* flow bins */

/*-------------------------------------------------------------------*/
unsigned int
GetHash(char *s, int len)
{
	int c, i;
	unsigned int hash = 0;

	/* bernstein's algorithm with XOR */	
	for (i = 0; i < len; i++) {
		c = *s++;
		hash = ((hash << 5) + hash) ^ c;
	}

	return (hash % NUM_CH_BINS);
}
/*-------------------------------------------------------------------*/
void
InitHashTable(void)
{
	int i;

	/* initialize flow hash table */
	for (i = 0; i < NUM_CH_BINS; i++)
		LIST_INIT(&g_flowBins[i]);
}
/*-------------------------------------------------------------------*/
flow *
SearchFlow(flow *f) 
{
	unsigned int bin = GetHash((char *)&f->saddr, sizeof(uint32_t));
	flow *fl;

	/* search for flow */
	LIST_FOREACH(fl, &g_flowBins[bin], link) {
		if (fl->saddr == f->saddr && 
			fl->daddr == f->daddr &&
			fl->sport == f->sport && 
			fl->dport == f->dport)
				return fl;
	}
	
	return NULL;
}
/*-------------------------------------------------------------------*/
void
InsertFlow(flow *f) 
{
	unsigned int bin = GetHash((char *)&f->saddr, sizeof(uint32_t));

	/* insert flow to hash table */
	LIST_INSERT_HEAD(&g_flowBins[bin], f, link);
	g_availChunks--;
}
/*-------------------------------------------------------------------*/
void
RemoveFlow(flow *f) 
{
	buffer *buf;

	/* remove any buffer in buffer list */
	while ((buf = f->bufRing[UP].head_buf) != NULL) {
		f->bufRing[UP].head_buf = buf->next_buf;
		AddToFreeBufferList(buf);
	}
	while ((buf = f->bufRing[DOWN].head_buf) != NULL) {
		f->bufRing[DOWN].head_buf = buf->next_buf;
		AddToFreeBufferList(buf);
	}

	/* remove flow from hash table */
	LIST_REMOVE(f, link);
}
/*-------------------------------------------------------------------*/

/* free buffer queue */
#define NUM_BATCH       1024
#define BATCH_SIZE_BITS 12
#define BATCH_SIZE      (1 << BATCH_SIZE_BITS)
static TAILQ_HEAD(, buffer) g_freeBufferList = 
	TAILQ_HEAD_INITIALIZER(g_freeBufferList);
static int g_freeBufferCount = 0;

/*-------------------------------------------------------------------*/
void
AddToFreeBufferList(buffer *b)
{
    TAILQ_INSERT_HEAD(&g_freeBufferList, b, link);
    g_freeBufferCount++;
}
/*-------------------------------------------------------------------*/
static void
AllocateMoreBuffer(void)
{
    buffer *b;
    int i;
    
    for (i = 0; i < BATCH_SIZE; i++) {
		if ((b = calloc(1, sizeof(struct buffer))) == NULL) {
			fprintf(stderr, "calloc() error\n");
			exit(-1);
		}
		AddToFreeBufferList(b);
    }
}
/*-------------------------------------------------------------------*/
static buffer *
RemoveFromFreeBufferList(void)
{
    buffer *b;

    b = TAILQ_FIRST(&g_freeBufferList);
    if (b == NULL) {
		AllocateMoreBuffer();
		b = TAILQ_FIRST(&g_freeBufferList);
    }

    TAILQ_REMOVE(&g_freeBufferList, b, link);
    g_freeBufferCount--;

    return(b);
}
/*-------------------------------------------------------------------*/
void
InitializeBufferList(void)
{
	buffer *b;

    b = RemoveFromFreeBufferList();
    AddToFreeBufferList(b);
}
/*-------------------------------------------------------------------*/
buffer *
GetBuffer(void) 
{
    return RemoveFromFreeBufferList();
}

