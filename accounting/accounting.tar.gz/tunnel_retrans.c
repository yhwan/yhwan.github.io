/*
 *  tunnel_retrans.c
 *
 *  Retransmit same data packet for 'n' times with different payload.
 *
 *  Younghwan Go
 *  yhwan@ndsl.kaist.edu
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <net/if.h>
#include <netinet/in.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <linux/if_packet.h>
#include <linux/sockios.h>
#include <pcap/pcap.h>
#include <pcap.h>

#define WINDOW_SCALE 7    /* depends on the machine */
#define BUFSIZE 4*1024
#define PKT_LEN (1400-14)
static int id = 12345;
static int drop = 0;
static unsigned int dropLen = 0, messageLen = 0;
static int g_fd;

/* timeout check */
#define TIMEOUT 1.0
struct timeval last_tv, curr_tv;

/*--------------------------------------------------------------------*/
/* tcp checksum structure */
struct psd_tcp {
	struct in_addr src;
	struct in_addr dst;
	unsigned char pad;
	unsigned char proto;
	unsigned short tcp_len;
};
/*--------------------------------------------------------------------*/
/* checksum calculation */
unsigned short
csum(unsigned short *addr, int len)
{
	int nleft = len;
	int sum = 0;
	unsigned short *w = addr;
	unsigned short answer = 0;

	while (nleft > 1) {
		sum += *w++;
		nleft -= 2;
	}
	if (nleft == 1) {
		*(unsigned char *)(&answer) = *(unsigned char *)w;
		sum += answer;
	}

	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	answer = ~sum;

	return answer;
}
/*--------------------------------------------------------------------*/
/* tcp checksum calculation */
unsigned short
csum_tcp(unsigned long src, unsigned long dst, unsigned short *data, int len)
{
	struct psd_tcp hdr;
	char tcpBuf[65535];
	unsigned short ans;

	memset(&hdr, 0, sizeof(hdr));
	hdr.src.s_addr = src;
	hdr.dst.s_addr = dst;
	hdr.pad = 0;
	hdr.proto = IPPROTO_TCP;
	hdr.tcp_len = htons(len);

	memcpy(tcpBuf, &hdr, sizeof(struct psd_tcp));
	memcpy(tcpBuf + sizeof(struct psd_tcp), data, len);
	ans = csum((unsigned short *)&tcpBuf, sizeof(struct psd_tcp) + len);

	return ans;
}
/*--------------------------------------------------------------------*/
/* create HTTP response header */
int
CreateResponseHeader(char *header, char *filename, bool isFileFound)
{
#define HTTP_1_0 "HTTP/1.0 200 OK\r\n"
#define HTTP_1_1 "HTTP/1.1 200 OK\r\n"
#define HTTP_NOT_FOUND "HTTP/1.1 404 Not Found\r\n"
#define HTTP_DATE "Date: "
#define HTTP_CONT_LENGTH "Content-Length: "

	struct stat file;
	char date[BUFSIZE], cont_length[BUFSIZE];
	time_t current_time;
	int res, off = 0;

	/* HTTP OK */
	if (isFileFound) {
		memcpy(header, HTTP_1_1, sizeof(HTTP_1_1) - 1);
		off += sizeof(HTTP_1_1) - 1;
	}
	else {
		memcpy(header, HTTP_NOT_FOUND, sizeof(HTTP_NOT_FOUND) - 1);
		off += sizeof(HTTP_NOT_FOUND) - 1;
	}

	/* Date */
	memcpy(header + off, HTTP_DATE, sizeof(HTTP_DATE) - 1);
	off += sizeof(HTTP_DATE) - 1;
	time(&current_time);
	sprintf(date, "%s\n", ctime(&current_time));
	memcpy(header + off, date, strlen(date) - 1);
	off += (strlen(date) - 1);

	/* Content-Length */
	if (isFileFound) {
		memcpy(header + off, HTTP_CONT_LENGTH, sizeof(HTTP_CONT_LENGTH) - 1);
		off += sizeof(HTTP_CONT_LENGTH) - 1;
		if (stat(filename, &file) != 0) {
			perror("stat() error");
			return -1;
		}
		messageLen = file.st_size;
		if ((res = sprintf(cont_length, "%lu\n", file.st_size)) < 0) {
			fprintf(stderr, "sprintf() error\n");
			return -1;
		}
		memcpy(header + off, cont_length, res);
		off += res;
	}
	
	memcpy(header + off, "\r\n", 2);
	off += 2;
	messageLen += off;
	
	return off;
}
/*--------------------------------------------------------------------*/
/* create packet TCP/IP header */
void
CreatePacketHeader(char *packet, char *rcvd_pkt, 
				 int len, int headerLen, int dataLen, int requestLen)
{
	struct iphdr *iph = (struct iphdr *)packet;
	struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
	struct iphdr *iph_recv = (struct iphdr *)rcvd_pkt;
	struct tcphdr *tcph_recv = (struct tcphdr *)(rcvd_pkt + sizeof(struct iphdr));
	
	/* initialize packet */
	memset(packet, 0, PKT_LEN);
	
	/* ip header */
	iph->ihl = 5;
	iph->version = 4;
	iph->tos = 0;
	iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + headerLen + len;
	iph->id = htons(id++);
	iph->frag_off = 0;
	iph->ttl = 64;
	iph->protocol = IPPROTO_TCP;
	iph->saddr = iph_recv->daddr;
	iph->daddr = iph_recv->saddr;
	iph->frag_off |= ntohs(IP_DF);
	iph->check = 0;
	iph->check = csum((unsigned short *)packet, sizeof(struct iphdr));
	
	/* tcp header */
	tcph->source = tcph_recv->dest;
	tcph->dest = tcph_recv->source;
	tcph->seq = htonl(ntohl(tcph_recv->ack_seq) + dataLen);
	tcph->ack_seq = htonl(ntohl(tcph_recv->seq) + requestLen);
	tcph->doff = (sizeof(struct tcphdr)) / 4;
	tcph->psh = 1;
	tcph->ack = 1;
	tcph->window = htons(14600 >> WINDOW_SCALE);
	tcph->check = 0;
}
/*--------------------------------------------------------------------*/
/* send data packet */
void
SendDataPacket(int sock, char *packet, 
			   struct sockaddr_in serv_addr, int len)
{
	if (sendto(sock, packet, len, 0, (struct sockaddr *)&serv_addr, 
			   sizeof(struct sockaddr)) < 0)  {
		perror("sendto() error");
		exit(-1);
	}
}
/*--------------------------------------------------------------------*/
/* calculate time difference */
double
CalculateTimeDiff(struct timeval last_tv)
{
	struct timeval curr_tv;
	double diff;

	gettimeofday(&curr_tv, NULL);
	diff = (curr_tv.tv_sec + curr_tv.tv_usec / 1e6) -
		(last_tv.tv_sec + last_tv.tv_usec / 1e6);

	return diff;
}
/*--------------------------------------------------------------------*/
/* start retransmission */
int
StartRetransmit(int sock, char *rcvd_pkt, char *filename, 
				struct sockaddr_in clnt_addr, int requestLen, int num)
{
	/* packet-related variables */
	char packet[PKT_LEN], data[PKT_LEN], message[PKT_LEN];
	struct iphdr *iph = (struct iphdr *)packet;
	struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
	struct iphdr *iph_ack = (struct iphdr *)message;
	struct tcphdr *tcph_ack = (struct tcphdr *)(message + sizeof(struct iphdr));
	int retransmit;
	
	/* file-related variables */
	int fd, len, dataLen = 0, headerLen = 0;
	bool isFileFound = true, receivedAck = false;
	int res, i;
	fd_set readSet, tempSet;
	struct timeval timeout;
	double time_diff;

	/* open file */
	if (filename[0] == '/')
		*filename++;
	if ((fd = open(filename, O_RDONLY, S_IRUSR|S_IWUSR)) == -1) {
		if (errno != ENOENT) {
			perror("open() error");
			exit(-1);
		}
		fprintf(stderr, "no file found\n");
		isFileFound = false;
	}

	/* create HTTP response header */
	if ((headerLen = CreateResponseHeader(data, filename, isFileFound)) == -1) {
		fprintf(stderr, "CreateResponseHeader() error\n");
		exit(-1);
	}

	fprintf(stderr, "%s", data);

	/* retransmission loop */
	if (isFileFound) {
		/* initialize fd set */
		FD_ZERO(&tempSet);
		FD_SET(sock, &tempSet);

		/* set select timeout (1ms) */
		timeout.tv_sec = 0;
		timeout.tv_usec = 1000;

		/* begin retransmission */
		while (1) {
			fprintf(stderr, 
					"Sending data packet (Offset: %d)! (Number of same packet: %d) / Destination: %s : %d\n", 
					dataLen, num, inet_ntoa(*(struct in_addr *)&iph->daddr), ntohs(tcph->dest));

			for (i = 0; i < num; i++) {
				if (i == 0) {
					len = read(fd, data + headerLen, 
							   PKT_LEN - sizeof(struct iphdr) - sizeof(struct tcphdr) - headerLen);
				}
				else {
					len = read(g_fd, data + headerLen, 
							   PKT_LEN - sizeof(struct iphdr) - sizeof(struct tcphdr) - headerLen);
				}
				if (len <= 0)
					break;

				else {
					/* create TCP/IP header */
					CreatePacketHeader(packet, rcvd_pkt, len, 
									   headerLen, dataLen, requestLen);
					memcpy(packet + sizeof(struct iphdr) + sizeof(struct tcphdr), 
						   data, headerLen + len);
					tcph->check = csum_tcp(iph->saddr, iph->daddr, 
										   (unsigned short *)(packet + sizeof(struct iphdr)), 
										   sizeof(struct tcphdr) + headerLen + len);
					
					SendDataPacket(sock, packet, clnt_addr, iph->tot_len);
					gettimeofday(&last_tv, NULL);
					
					while (1) {
						/* select */
						readSet = tempSet;
						if ((res = select(sock + 1, &readSet, NULL, NULL, &timeout)) < 0) {
							perror("select() error");
							exit(-1);
						}
						/* select timeout */
						if (res == 0) {
							/* check if timeout occurred for specified client */
							if (CalculateTimeDiff(last_tv) > TIMEOUT) {
								fprintf(stderr, "Packet Drop! Retransmitting Data Packet!\n");
								SendDataPacket(sock, packet, clnt_addr, iph->tot_len);
								gettimeofday(&last_tv, NULL);
								drop++;
								dropLen += iph->tot_len;
							}
						}
						else {
							receivedAck = false;
							while (1) {
								if ((res = recv(sock, message, sizeof(message), 0)) > 0) {
									/* received ACK */
									if (tcph_ack->ack && 
										iph_ack->saddr == clnt_addr.sin_addr.s_addr && 
										tcph_ack->source == clnt_addr.sin_port && 
										tcph_ack->ack_seq == htonl(ntohl(tcph->seq) + headerLen + len)) {
										fprintf(stderr, 
												"Rececived ACK Packet! (Len: %d) / Source: %s : %d\n",
												res, 
												inet_ntoa(*(struct in_addr *)&iph_ack->saddr), 
												ntohs(tcph_ack->source));
										receivedAck = true;
									}
									/* receive RST */
									else if (tcph_ack->rst &&
											 iph_ack->saddr == clnt_addr.sin_addr.s_addr && 
											 tcph_ack->source == clnt_addr.sin_port) {
										fprintf(stderr,
												"Received RST Packet! (Len: %d) / Source: %s : %d\n",
												res, inet_ntoa(*(struct in_addr *)&iph_ack->saddr), 
												ntohs(tcph_ack->source));
										return -1;
									}
								}
								else if (res < 0) {
									if (errno != EAGAIN && errno != EWOULDBLOCK) {
										perror("recv() error");
										exit(-1);
									}
									if (!receivedAck) {
										/* check if timeout occurred for specified client */
										if (CalculateTimeDiff(last_tv) > TIMEOUT) {
											fprintf(stderr, "Packet Drop! Retransmitting Data Packet!\n");
											SendDataPacket(sock, packet, clnt_addr, iph->tot_len);
											gettimeofday(&last_tv, NULL);
											drop++;
											dropLen += iph->tot_len;
										}
									}
									break;
								}
							}
							/* send next packet */
							if (receivedAck)
								break;
						}
					}
				}
			}
			fprintf(stderr, "\n");
			if (len <= 0)
				break;
			dataLen += len + headerLen;
			headerLen = 0;
		}
		fprintf(stderr, "Finished Retransmission! Packet Drop Num: %d / Len: %u B\n", 
				drop, dropLen);
	}
	else {
		/* create packet header */
		CreatePacketHeader(packet, rcvd_pkt, 0, headerLen, dataLen, requestLen);
		memcpy(packet + sizeof(struct iphdr) + sizeof(struct tcphdr), data, headerLen + len);
		tcph->check = csum_tcp(iph->saddr, iph->daddr, 
							   (unsigned short *)(packet + sizeof(struct iphdr)), 
							   sizeof(struct tcphdr) + headerLen + len);

		/* send NOT_FOUND error */
		SendDataPacket(sock, packet, clnt_addr, iph->tot_len);
	}
	return 0;
}
/*--------------------------------------------------------------------*/
/* handle HTTP request */
int
HandleRequest(int sock, struct sockaddr_in clnt_addr, char *buf, 
			  char *rcvd_pkt, int len, int num)
{
#define HTTP_GET "GET"
#define SKIP_SPACES(x)                                 \
	while((*x) && isspace((int)(*x))) x++;
#define GET_STRING(x, buf)                             \
	i = 0;                                             \
	while (i < sizeof(buf) && *x && !isspace((int)*x)) \
		buf[i++] = *x++;                               \
	if (i == sizeof(buf) || *x == 0)                   \
		goto done_with_error;                          \
	buf[i] = 0;

	char filename[BUFSIZE];
	int i, res;

	/* see if we have a full request */
	if (strstr(buf, "\n\n") == NULL && strstr(buf, "\n\r\n") == NULL) {
		fprintf(stderr, "Incomplete HTTP request\n");
		return -1;
	}

	/* we support only GET */
	if (strncmp(buf, HTTP_GET, sizeof(HTTP_GET) - 1) != 0) {
		fprintf(stderr, "Malformed HTTP request\n");
		return -1;
	}

	/* move to the start of filename */
	buf += sizeof(HTTP_GET);
	SKIP_SPACES(buf);

	/* retrieve the filename */	
	GET_STRING(buf, filename);

	/* start retransmission */
	if (StartRetransmit(sock, rcvd_pkt, filename, clnt_addr, len, num) == -1) {
		fprintf(stderr, "StartRetransmit() error\n");
		return -1;
	}

	return 0;

 done_with_error:
	fprintf(stderr, "Malformed HTTP request\n");
	return -1;
}
/*--------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
	int sock, serv_sock, clnt_sock;
	struct sockaddr_in clnt_addr, serv_addr;
	unsigned int clnt_addr_size;
 	const int one = 1;
	char buf[BUFSIZE];
	int len = 0;

	/* check parameter */
	if (argc != 3) {
		fprintf(stderr, 
				"Usage: %s <port> <num of same pkt>\n", 
				argv[0]);
		exit(-1);
	}

	/* open file to generate random payload */
	if ((g_fd = open("/dev/urandom", O_RDONLY)) == -1) {
		perror("open() error");
		exit(-1);
	}

	/* create raw socket */
	if ((sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) < 0) {
		perror("socket() error");
		exit(-1);
	}

	/* create tcp socket */
    if ((serv_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		fprintf(stderr, "socket() error\n");
		exit(-1);
    }

	/* set server address */
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));

	/* bind raw socket */
	if (bind(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
		perror("bind() error");
		exit(-1);
	}

	/* bind tcp socket */
	if (bind(serv_sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
		perror("bind() error");
		exit(-1);
	}

	/* tell kernel to not handle ip & tcp header */
	if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
		perror("setsockopt() error");
		exit(-1);
	}

	/* set sock to non-block */
	if (fcntl(sock, F_SETFL, O_NONBLOCK) == -1) {
		perror("fcntl() error");
		exit(-1);
	}

    /* listen on tcp socket */
    if (listen(serv_sock, 5) == -1) {
		perror("connect() error");
		exit(-1);
    }

	while (1) {
		/* accept on tcp socket */
		clnt_addr_size = sizeof(clnt_addr);
		if ((clnt_sock = accept(serv_sock, 
								(struct sockaddr*)&clnt_addr, &clnt_addr_size)) == -1) {
			perror("accept() error");
			exit(-1);
		}
		if (!fork()) {
			close(serv_sock);	

			char message[PKT_LEN];
			struct iphdr *iph_recv = (struct iphdr *)message;
			struct tcphdr *tcph_recv = (struct tcphdr *)(message + sizeof(struct iphdr));
			int res;

			while (1) {
				if ((res = recv(sock, message, sizeof(message), 0)) > 0) {
					/* retreive TCP-handshake ACK from the client */
					if (tcph_recv->ack && 
						iph_recv->saddr == clnt_addr.sin_addr.s_addr && 
						tcph_recv->source == clnt_addr.sin_port) {
						break;			
					}
				}
				else if (res < 0) {
					if (errno != EAGAIN && errno != EWOULDBLOCK) {
						perror("recv() error");
						return -1;
					}
				}
			}

			/* read HTTP request */
			if ((len = read(clnt_sock, buf, BUFSIZE)) > 0) {
				fprintf(stderr, "\n%s", buf);
				/* handle request */
				if (HandleRequest(sock, clnt_addr, buf, 
								  message, len, atoi(argv[2])) == -1) {
					fprintf(stderr, "HandleRequest() error\n");
				}
			}			
			close(clnt_sock);
			exit(-1);
		}
	}
	return 0;
}
/*--------------------------------------------------------------------*/
